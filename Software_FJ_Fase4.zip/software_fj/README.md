# Software FJ – Sistema Integral de Gestión de Clientes, Servicios y Reservas

Proyecto de la **Fase 4 – Componente práctico (Prácticas simuladas)** del curso
**Programación (213023)**, Universidad Nacional Abierta y a Distancia (UNAD).

Aplicación en **Python 3.8+** orientada a objetos, **sin base de datos** (solo listas
internas) y con **manejo avanzado de excepciones**. Los errores y eventos se registran
en `logs/software_fj.log`.

## Cómo ejecutarlo

```bash
python main.py
```

No requiere instalar librerías externas (solo la biblioteca estándar de Python).

## Estructura

| Archivo | Contenido |
|---|---|
| `excepciones.py` | Jerarquía de excepciones personalizadas (`ErrorSoftwareFJ` y derivadas) |
| `logger.py` | Configuración del archivo de logs |
| `entidad.py` | Clase abstracta `EntidadBase` (id, `describir()`, `validar()`) |
| `cliente.py` | Clase `Cliente` con encapsulación y validaciones estrictas |
| `servicios.py` | Clase abstracta `Servicio` + `SalaReuniones`, `AlquilerEquipo`, `AsesoriaEspecializada` |
| `reserva.py` | Clase `Reserva` (confirmar, cancelar, procesar) y `EstadoReserva` |
| `gestor.py` | `GestorSoftwareFJ`: listas internas y ejecución segura de operaciones |
| `main.py` | Simulación de 35 operaciones (válidas e inválidas) |

## Requisitos del enunciado y dónde se cumplen

| Requisito | Dónde |
|---|---|
| Clase abstracta de entidades generales | `EntidadBase` (`entidad.py`) |
| Cliente con validaciones y encapsulación | `Cliente` (`cliente.py`) |
| Servicio abstracto + 3 servicios hijos, polimorfismo | `servicios.py` |
| Reserva con cliente, servicio, duración y estado | `Reserva` (`reserva.py`) |
| Métodos sobrecargados | `calcular_costo()` (parámetros opcionales) y `cotizar()` (`singledispatchmethod`) |
| Excepciones personalizadas | `excepciones.py` |
| `try/except`, `try/except/else`, `try/except/finally` | `reserva.py` y `gestor.py` (`_ejecutar_seguro`) |
| Encadenamiento de excepciones (`raise ... from ...`) | `cliente.py`, `reserva.py`, `gestor.py` |
| Archivo de logs | `logs/software_fj.log` |
| Mínimo 10 operaciones simuladas | `main.py` (35 operaciones) |

## Cómo subirlo a GitHub

```bash
git clone <enlace-del-repositorio>
# copiar aquí los archivos del proyecto
git add .
git commit -m "Software FJ: sistema de clientes, servicios y reservas"
git push
```
